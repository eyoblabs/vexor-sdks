# Changelog

## 0.1.2

- Add repository, bugs, homepage, keywords, sideEffects, and explicit `publishConfig: { access: "public" }` metadata.

## 0.1.1

- Add `storageConnections.awsIdentity()` for AWS role trust-policy setup.
- Preserve resumable upload details when offset reconciliation fails.
- Parse `Retry-After` values and run typechecking plus builds before publishing.
- Clarify AWS role and external ID setup in the SDK guide.
